// classes that store the metadata of the game
class BlackJackMetadata {
//    public static final int numOfDeck = 1;
    public static final String[] suits = new String[]{"clubs", "diamonds", "hearts", "spades"};
    public static final Integer[] ranks = new Integer[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
}
